package com.csye7374.musicplayer;
import com.csye7374.musicplayer.MusicPlayerAPI;

public class MusicPlayerFactory {
	
	//Implementation of Loose coupling and Lazy Singleton factory

	// Private static instance of the MusicPlayer
    private static MusicPlayerAPI musicPlayerInstance;

    // Private constructor to prevent instantiation
    private MusicPlayerFactory() {}

    // Public static method to get the singleton instance
    public static MusicPlayerAPI getMusicPlayer() {
        if (musicPlayerInstance == null) {
            musicPlayerInstance = new BasicMusicPlayer();
        }
        return musicPlayerInstance;
    }
}
