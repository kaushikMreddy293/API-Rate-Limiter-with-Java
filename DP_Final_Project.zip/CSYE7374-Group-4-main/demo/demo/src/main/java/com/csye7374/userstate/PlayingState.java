
package com.csye7374.userstate;

public class PlayingState implements UserState {
    @Override
    public void handleAction(UserContext context) {
        System.out.println("User is playing a song.");
        context.setState(this);
    }

    @Override
    public String toString() {
        return "Playing State";
    }
}
