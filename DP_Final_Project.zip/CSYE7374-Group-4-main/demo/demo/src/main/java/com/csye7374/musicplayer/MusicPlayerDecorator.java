package com.csye7374.musicplayer;

public abstract class MusicPlayerDecorator implements MusicPlayerAPI {
    protected MusicPlayerAPI decoratedPlayer;

    public MusicPlayerDecorator(MusicPlayerAPI decoratedPlayer) {
        this.decoratedPlayer = decoratedPlayer;
    }

    @Override
    public void play(String[] song) {
        decoratedPlayer.play(song);
    }
}
