package com.csye7374.demo.observer;

public interface RateLimitObserver {
	void notifyLimitReached(String clientIp);
}
