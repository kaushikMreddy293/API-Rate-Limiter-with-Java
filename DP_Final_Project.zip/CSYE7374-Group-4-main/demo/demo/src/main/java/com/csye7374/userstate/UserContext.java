
package com.csye7374.userstate;

public class UserContext {
    private UserState state;

    public UserContext() {
        state = null;
    }

    public void setState(UserState state) {
        this.state = state;
    }

    public UserState getState() {
        return state;
    }
}
