package com.csye7374.demo.strategy;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;


import com.csye7374.demo.decorator.LoggingRateLimitDecorator;
//import com.csye7374.demo.decorator.LoggingRateLimitDecorator;
import com.csye7374.demo.observer.ObservableRateLimit;
import com.csye7374.demo.observer.RateLimitNotifier;

@Configuration
public class RateLimitStrategyConfig {

    @Bean
    @Profile("premium")
    public RateLimitStrategy premiumRateLimitStrategy() {
        return new TokenBucketRateLimitStrategy();
    }

    @Bean
    @Profile("standard")
    public RateLimitStrategy standardRateLimitStrategy() {
        return new FixedWindowRateLimitStrategy();
    }
    
//    @Bean
//    public RateLimitStrategy loggingRateLimitDecoratorImpl(RateLimitStrategy rateLimitStrategy) {
//        return new LoggingRateLimitDecorator(rateLimitStrategy);
//    }

    @Bean
    public ObservableRateLimit observableRateLimit(RateLimitStrategy rateLimitStrategy) {
        ObservableRateLimit observableRateLimit = new ObservableRateLimit(rateLimitStrategy);
        observableRateLimit.addObserver(new RateLimitNotifier());
        return observableRateLimit;
    }

//    @Bean
//    public RateLimitingFilter rateLimitingFilter(ObservableRateLimit observableRateLimit) {
//        return new RateLimitingFilter(observableRateLimit);
//    }
}
