package com.csye7374.musicplayer;

import com.csye7374.apidata.MusicTrack;

public class NowPlayingDecorator extends MusicPlayerDecorator {

    public NowPlayingDecorator(MusicPlayerAPI decoratedPlayer) {
        super(decoratedPlayer);
    }

//    @Override
//    public void play(String song) {
//        // Add "Now Playing" behavior before delegating to the base player
//        System.out.println("\n 🎶 Now Playing: " + song + " 🎶 \n");
////        super.play(song);
//    }
    
//    @Override
//    public void play(MusicTrack musicTrack) {
//        // Build the "Now Playing" string using MusicTrack properties
//        String nowPlayingMessage = new StringBuilder()
//                .append("\n 🎶 Now Playing: ")
//                .append(musicTrack.getTitle())
//                .append(" by ")
//                .append(musicTrack.getArtist())
//                .append(" from the album ")
//                .append(musicTrack.getAlbum())
//                .append(" (")
//                .append(musicTrack.getReleaseYear())
//                .append(") - Genre: ")
//                .append(musicTrack.getGenre())
//                .append(" | Duration: ")
//                .append(musicTrack.getDuration())
//                .append(" 🎶 \n")
//                .toString();
//
//        // Print the "Now Playing" message
//        System.out.println(nowPlayingMessage);
//
//        // Optionally call the decorated player's play method
//        super.play(musicTrack.getTitle());
//    }
    
    @Override
    public void play(String[] songDetails) {
        // Here we simulate fetching the song details for the given title and use the Builder to create a MusicTrack
        MusicTrack track = createMusicTrackFromTitle(songDetails);

        // Build the "Now Playing" message using MusicTrack properties
        String nowPlayingMessage = new StringBuilder()
                .append("\n 🎶 Now Playing: ")
                .append(track.getTitle())
                .append(" by ")
                .append(track.getArtist())
                .append(" from the album ")
                .append(track.getAlbum())
                .append(" (")
                .append(track.getReleaseYear())
                .append(") - Genre: ")
                .append(track.getGenre())
                .append(" | Duration: ")
                .append(track.getDuration())
                .append(" 🎶 \n")
                .toString();

        // Print the "Now Playing" message
        System.out.println(nowPlayingMessage);

    }

    // Helper method to create a MusicTrack object from a song title
    private MusicTrack createMusicTrackFromTitle(String[] songTitle) {
        
        return new MusicTrack.Builder()
                .withId(Integer.parseInt(songTitle[0]))
                .withTitle(songTitle[1])
                .withArtist(songTitle[2])
                .withAlbum(songTitle[3])
                .withGenre(songTitle[4])
                .withReleaseYear(Integer.parseInt(songTitle[5]))
                .withDuration(songTitle[6])
                .build();
    }
}