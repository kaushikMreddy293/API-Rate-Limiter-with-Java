package com.csye7374.command;

import java.util.List;

import com.csye7374.musicplayer.MusicPlayerAPI;

public class PlayNextSongCommand implements MusicCommand {
    private MusicPlayerAPI musicPlayer;
    private List<String> songList;
    private int currentIndex;

    public PlayNextSongCommand(MusicPlayerAPI musicPlayer, List<String> songList, int currentIndex) {
        this.musicPlayer = musicPlayer;
        this.songList = songList;
        this.currentIndex = currentIndex;
    }

    @Override
    public void execute() {
        if (currentIndex < songList.size() - 1) {
            currentIndex++;
            String[] songDetails = songList.get(currentIndex).split(",");
            musicPlayer.play(songDetails);
        } else {
            System.out.println("No next song available. Please select a song manually.\n");
        }
    }

    public int getCurrentIndex() {
        return currentIndex;
    }
}
