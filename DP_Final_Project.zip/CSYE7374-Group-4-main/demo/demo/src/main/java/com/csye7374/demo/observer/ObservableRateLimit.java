package com.csye7374.demo.observer;

import com.csye7374.demo.strategy.RateLimitStrategy;
import java.util.*;

public class ObservableRateLimit implements RateLimitStrategy {
    private final RateLimitStrategy wrapped;
    private final List<RateLimitObserver> observers = new ArrayList<>();

    public ObservableRateLimit(RateLimitStrategy wrapped) {
        this.wrapped = wrapped;
    }

    public void addObserver(RateLimitObserver observer) {
        observers.add(observer);
    }

    @Override
    public boolean isAllowed(String clientIp) {
        boolean allowed = wrapped.isAllowed(clientIp);
        if (!allowed) {
            notifyObservers(clientIp);
        }
        return allowed;
    }

    private void notifyObservers(String clientIp) {
        for (RateLimitObserver observer : observers) {
            observer.notifyLimitReached(clientIp);
        }
    }
}