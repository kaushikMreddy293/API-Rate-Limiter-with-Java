package com.csye7374.musicplayer;

public class MusicPlayerProxy implements MusicPlayerAPI {
    private final MusicPlayerAPI musicPlayer;
    private final boolean isPremiumUser;

    public MusicPlayerProxy(MusicPlayerAPI musicPlayer, boolean isPremiumUser) {
        this.musicPlayer = musicPlayer;
        this.isPremiumUser = isPremiumUser;
    }

    @Override
    public void play(String[] songs) {
        musicPlayer.play(songs); // Allow all actions; rate limiting is handled by RateLimiterApplication
    }
}
