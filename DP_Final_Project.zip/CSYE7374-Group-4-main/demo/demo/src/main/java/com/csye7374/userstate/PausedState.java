
package com.csye7374.userstate;

public class PausedState implements UserState {
    @Override
    public void handleAction(UserContext context) {
        System.out.println("User has paused the song.");
        context.setState(this);
    }

    @Override
    public String toString() {
        return "Paused State";
    }
}
