
package com.csye7374.musicplayer;

import java.util.HashMap;
import java.util.Map;

public class SongMetadataFactory {
    private static final Map<String, SongMetadata> metadataMap = new HashMap<>();

    public static SongMetadata getSongMetadata(String title, String artist) {
        String key = title + ":" + artist;
        if (!metadataMap.containsKey(key)) {
            metadataMap.put(key, new SongMetadata(title, artist));
        }
        return metadataMap.get(key);
    }
}
