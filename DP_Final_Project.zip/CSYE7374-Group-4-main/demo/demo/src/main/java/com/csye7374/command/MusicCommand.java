package com.csye7374.command;

public interface MusicCommand {

	void execute();
}
