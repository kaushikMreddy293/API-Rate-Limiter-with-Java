package com.csye7374.demo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.csye7374.apidata.FileUtility;
import com.csye7374.command.MusicCommandInvoker;
import com.csye7374.command.PlayNextSongCommand;
import com.csye7374.command.PlaySpecificSongCommand;
import com.csye7374.musicplayer.MusicPlayerAPI;
import com.csye7374.musicplayer.MusicPlayerFactory;
import com.csye7374.musicplayer.MusicPlayerProxy;
import com.csye7374.musicplayer.NowPlayingDecorator;
import com.csye7374.musicplayer.Playlist;

///
import com.csye7374.demo.strategy.FixedWindowRateLimitStrategy;
import com.csye7374.demo.strategy.TokenBucketRateLimitStrategy;
import com.csye7374.demo.strategy.RateLimitStrategy;
import com.csye7374.demo.observer.ObservableRateLimit;
import com.csye7374.demo.observer.RateLimitNotifier;

@SpringBootApplication
public class RateLimiterApplication {

    public static void main(String[] args) {
        SpringApplication.run(RateLimiterApplication.class, args);
        Scanner scanner = new Scanner(System.in);

        System.out.println("🎵 Welcome to the Music Console! 🎵");

        String filePath = "src/main/resources/apidata"; // Relative path to CSV file
        FileUtility fileUtility = new FileUtility();

        try {
            List<String> csvLines = fileUtility.readCsvFile(filePath);

            System.out.println("Choose your user type:");
            System.out.println("1. Standard User");
            System.out.println("2. Premium User");
            System.out.print("Enter your choice: ");
            int userTypeChoice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            // Initialize Rate Limiter
            RateLimitStrategy fwRateLimiter = new FixedWindowRateLimitStrategy();
            RateLimitStrategy tbRateLimiter = new TokenBucketRateLimitStrategy();
            ObservableRateLimit observableRateLimit = (userTypeChoice == 1)
                    ? new ObservableRateLimit(fwRateLimiter)
                    : new ObservableRateLimit(tbRateLimiter);

            observableRateLimit.addObserver(new RateLimitNotifier());
            String clientIp = "192.168.1.1"; // Simulated client IP

            // Debug: Verify initialization
            System.out.println("Rate limiter initialized for user type: " + (userTypeChoice == 1 ? "Standard" : "Premium"));

            MusicPlayerAPI basicMusicPlayer = MusicPlayerFactory.getMusicPlayer();
            MusicPlayerAPI proxyMusicPlayer = new MusicPlayerProxy(new NowPlayingDecorator(basicMusicPlayer), userTypeChoice == 2);

            MusicCommandInvoker invoker = new MusicCommandInvoker();
            int currentSongIndex = -1;

            List<Playlist> playlists = new ArrayList<>();
            boolean continuePlaying = true;

            while (continuePlaying) {
                System.out.println("\nOptions:");
                System.out.println("1. Browse Songs");
                System.out.println("2. Play a Specific Song");
                System.out.println("3. Play Next Song");
                System.out.println("4. Create Playlist");
                System.out.println("5. View Playlist");
                System.out.println("6. Add Song to Playlist");
                System.out.println("7. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                boolean isRestrictedAction = choice == 2 || choice == 3;
                
                
                 if (isRestrictedAction && !observableRateLimit.isAllowed(clientIp)) {
                    System.out.println("Rate limit exceeded. You can only browse songs, view playlists, or exit.\n");
                    continue;
                }

                
                switch (choice) {
                    case 1:
                        System.out.println("Available Songs:");
                        for (int i = 0; i < csvLines.size(); i++) {
                            String[] songDetails = csvLines.get(i).split(",");
                            System.out.println((i + 1) + ". " + songDetails[1] + " by " + songDetails[2]);
                        }
                        break;

                    case 2:
 
                    	
                        System.out.print("Enter the song number to play: ");
                        int songNumber = scanner.nextInt();
                        scanner.nextLine();

                        if (songNumber > 0 && songNumber <= csvLines.size()) {
                            invoker.setCommand(new PlaySpecificSongCommand(proxyMusicPlayer, csvLines, songNumber - 1));
                            invoker.executeCommand();
                            currentSongIndex = songNumber - 1;
                        } else {
                            System.out.println("Invalid song number.");
                        }
                        break;

                    case 3:
                    	
                    	 
                        if (currentSongIndex < 0) {
                            System.out.println("Please select a specific song first, then use the Next Song feature.");
                  
                        } else if (currentSongIndex < csvLines.size() - 1) {
                            invoker.setCommand(new PlayNextSongCommand(proxyMusicPlayer, csvLines, currentSongIndex));
                            invoker.executeCommand();
                            currentSongIndex++;
                        } else {
                            System.out.println("You have reached the end of the playlist.");
                        }
                        break;

                    case 4:
                        System.out.print("Enter playlist name: ");
                        String playlistName = scanner.nextLine();
                        playlists.add(new Playlist.PlaylistBuilder().setName(playlistName).build());
                        System.out.println("Playlist created: " + playlistName);
                        break;

                    case 5:
                        if (playlists.isEmpty()) {
                            System.out.println("No playlists available.");
                        } else {
                            System.out.println("Choose a playlist to view:");
                            for (int i = 0; i < playlists.size(); i++) {
                                System.out.println((i + 1) + ". " + playlists.get(i).getName());
                            }
                            int playlistChoice = scanner.nextInt();
                            scanner.nextLine();
                            if (playlistChoice > 0 && playlistChoice <= playlists.size()) {
                                System.out.println(playlists.get(playlistChoice - 1));
                            } else {
                                System.out.println("Invalid choice.");
                            }
                        }
                        break;

                    case 6:
                        if (playlists.isEmpty()) {
                            System.out.println("No playlists available. Please create one first.");
                        } else {
                            System.out.println("Choose a playlist to add the song:");
                            for (int i = 0; i < playlists.size(); i++) {
                                System.out.println((i + 1) + ". " + playlists.get(i).getName());
                            }
                            int playlistChoice = scanner.nextInt();
                            scanner.nextLine();

                            if (playlistChoice > 0 && playlistChoice <= playlists.size()) {
                                System.out.print("Enter the song number to add: ");
                                int songToAdd = scanner.nextInt();
                                scanner.nextLine();

                                if (songToAdd > 0 && songToAdd <= csvLines.size()) {
                                    String[] songDetails = csvLines.get(songToAdd - 1).split(",");
                                    String songTitle = songDetails[1] + " by " + songDetails[2];
                                    Playlist selectedPlaylist = playlists.get(playlistChoice - 1);
                                    playlists.set(playlistChoice - 1,
                                            new Playlist.PlaylistBuilder().setName(selectedPlaylist.getName())
                                                    .addSong(songTitle).build());
                                    System.out.println("Added: " + songTitle + " to playlist " + selectedPlaylist.getName());
                                } else {
                                    System.out.println("Invalid song number.");
                                }
                            } else {
                                System.out.println("Invalid playlist choice.");
                            }
                        }
                        break;

                    case 7:
                        System.out.println("Thank you for using the Music Console! Goodbye! 👋");
                        continuePlaying = false;
                        break;

                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage());
        }
    }
}
