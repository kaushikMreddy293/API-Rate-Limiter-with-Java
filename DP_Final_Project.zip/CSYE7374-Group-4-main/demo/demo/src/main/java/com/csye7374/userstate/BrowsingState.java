
package com.csye7374.userstate;

public class BrowsingState implements UserState {
    @Override
    public void handleAction(UserContext context) {
        System.out.println("User is browsing songs.");
        context.setState(this);
    }

    @Override
    public String toString() {
        return "Browsing State";
    }
}


// able to add musltoiple songs in playlist.
//rate limit should work on 2,3
//