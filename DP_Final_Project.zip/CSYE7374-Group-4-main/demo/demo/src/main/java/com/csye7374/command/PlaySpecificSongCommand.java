package com.csye7374.command;

import java.util.List;

import com.csye7374.musicplayer.MusicPlayerAPI;

public class PlaySpecificSongCommand implements MusicCommand {
    private MusicPlayerAPI musicPlayer;
    private List<String> songList;
    private int songIndex;

    public PlaySpecificSongCommand(MusicPlayerAPI musicPlayer, List<String> songList, int songIndex) {
        this.musicPlayer = musicPlayer;
        this.songList = songList;
        this.songIndex = songIndex;
    }

    @Override
    public void execute() {
        if (songIndex >= 0 && songIndex < songList.size()) {
            String[] songDetails = songList.get(songIndex).split(",");
            musicPlayer.play(songDetails);
        } else {
            System.out.println("Invalid song number. Please try again.\n");
        }
    }
}

