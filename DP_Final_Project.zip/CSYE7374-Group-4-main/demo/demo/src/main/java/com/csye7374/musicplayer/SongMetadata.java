
package com.csye7374.musicplayer;

public class SongMetadata {
    private final String title;
    private final String artist;

    public SongMetadata(String title, String artist) {
        this.title = title;
        this.artist = artist;
    }

    @Override
    public String toString() {
        return title + " by " + artist;
    }
}
