package com.csye7374.command;

public class MusicCommandInvoker {
	
	private MusicCommand command;

    public void setCommand(MusicCommand command) {
        this.command = command;
    }

    public void executeCommand() {
        if (command != null) {
            command.execute();
        }
    }

}

