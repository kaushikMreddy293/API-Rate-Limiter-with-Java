
package com.csye7374.userstate;

public interface UserState {
    void handleAction(UserContext context);
}
