package com.csye7374.musicplayer;

public interface MusicPlayerAPI {
	 void play(String[] song);
}
