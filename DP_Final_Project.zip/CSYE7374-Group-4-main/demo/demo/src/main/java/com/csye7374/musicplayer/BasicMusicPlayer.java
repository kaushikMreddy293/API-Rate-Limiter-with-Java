package com.csye7374.musicplayer;

public class BasicMusicPlayer implements MusicPlayerAPI {

	@Override
    public void play(String[] song) {
		//This code won't run due to overriding
        System.out.println("Playing: " + song);
    }
}
