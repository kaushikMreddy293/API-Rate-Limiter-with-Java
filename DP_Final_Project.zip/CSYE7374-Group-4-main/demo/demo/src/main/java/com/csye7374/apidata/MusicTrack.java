package com.csye7374.apidata;

public class MusicTrack {

	private int id;
    private String title;
    private String artist;
    private String album;
    private String genre;
    private int releaseYear;
    private String duration;

    // Constructor
    private MusicTrack(Builder builder) {
        this.id = builder.id;
        this.title = builder.title;
        this.artist = builder.artist;
        this.album = builder.album;
        this.genre = builder.genre;
        this.releaseYear = builder.releaseYear;
        this.duration = builder.duration;
    }
    
    public MusicTrack(String csvString) {
        String[] parts = csvString.split(",");
        if (parts.length == 7) {
            this.id = Integer.parseInt(parts[0].trim());
            this.title = parts[1].trim();
            this.artist = parts[2].trim();
            this.album = parts[3].trim();
            this.genre = parts[4].trim();
            this.releaseYear = Integer.parseInt(parts[5].trim());
            this.duration = parts[6].trim();
        } else {
            throw new IllegalArgumentException("Invalid CSV format: " + csvString);
        }
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public void setReleaseYear(int releaseYear) {
        this.releaseYear = releaseYear;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    // toString method for easy printing
    @Override
    public String toString() {
        return "MusicTrack{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", artist='" + artist + '\'' +
                ", album='" + album + '\'' +
                ", genre='" + genre + '\'' +
                ", releaseYear=" + releaseYear +
                ", duration='" + duration + '\'' +
                '}';
    }
    
    
 // Nested Builder class
    public static class Builder {
        private int id;
        private String title;
        private String artist;
        private String album;
        private String genre;
        private int releaseYear;
        private String duration;

        // Builder methods for each field
        public Builder withId(int id) {
            this.id = id;
            return this;
        }

        public Builder withTitle(String title) {
            this.title = title;
            return this;
        }

        public Builder withArtist(String artist) {
            this.artist = artist;
            return this;
        }

        public Builder withAlbum(String album) {
            this.album = album;
            return this;
        }

        public Builder withGenre(String genre) {
            this.genre = genre;
            return this;
        }

        public Builder withReleaseYear(int releaseYear) {
            this.releaseYear = releaseYear;
            return this;
        }

        public Builder withDuration(String duration) {
            this.duration = duration;
            return this;
        }

        // Build method to create MusicTrack object
        public MusicTrack build() {
            return new MusicTrack(this);
        }
	
}
}
