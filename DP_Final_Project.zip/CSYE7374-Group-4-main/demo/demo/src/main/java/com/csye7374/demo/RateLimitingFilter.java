//package com.csye7374.demo;
//
//import java.io.IOException;
//
//import org.springframework.web.filter.OncePerRequestFilter;
//
//import com.csye7374.demo.strategy.RateLimitStrategy;
//
//import jakarta.servlet.FilterChain;
//import jakarta.servlet.ServletException;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
//
//public class RateLimitingFilter extends OncePerRequestFilter {
//
//    private final RateLimitStrategy rateLimitStrategy;
//
//    public RateLimitingFilter(RateLimitStrategy rateLimitStrategy) {
//        this.rateLimitStrategy = rateLimitStrategy;
//    }
//
//	@Override
//	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
//			throws ServletException, IOException {
//		String clientIp = request.getRemoteAddr();
//
//        if (!rateLimitStrategy.isAllowed(clientIp)) {
//            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
//            response.getWriter().write("Too many requests. Please try again later.");
//            return;
//        }
//
//        filterChain.doFilter(request, response);
//		
//	}
//}
//
