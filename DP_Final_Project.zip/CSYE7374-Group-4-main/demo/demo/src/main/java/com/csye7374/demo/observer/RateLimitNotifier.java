package com.csye7374.demo.observer;

public class RateLimitNotifier implements RateLimitObserver{
	@Override
    public void notifyLimitReached(String clientIp) {
        System.out.println("Rate limit reached for IP: " + clientIp);
    }
}
