package com.csye7374.demo.strategy;

public interface RateLimitStrategy {
	boolean isAllowed(String clientIp);
}
