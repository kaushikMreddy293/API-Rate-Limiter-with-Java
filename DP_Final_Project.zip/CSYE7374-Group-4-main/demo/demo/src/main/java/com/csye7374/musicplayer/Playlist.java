
package com.csye7374.musicplayer;

import java.util.ArrayList;
import java.util.List;

// Builder Pattern for constructing playlists
public class Playlist {
    private final String name;
    private final List<String> songs;

    // Private constructor to enforce the use of the builder
    private Playlist(PlaylistBuilder builder) {
        this.name = builder.name;
        this.songs = builder.songs;
    }

    // Getters
    public String getName() {
        return name;
    }

    public List<String> getSongs() {
        return songs;
    }

    // Builder Class
    public static class PlaylistBuilder {
        private String name;
        private List<String> songs = new ArrayList<>();

        public PlaylistBuilder setName(String name) {
            this.name = name;
            return this;
        }

        public PlaylistBuilder addSong(String song) {
            this.songs.add(song);
            return this;
        }

        public Playlist build() {
            return new Playlist(this);
        }
    }

    @Override
    public String toString() {
        return "Playlist: " + name + "\nSongs: " + songs;
    }
}
